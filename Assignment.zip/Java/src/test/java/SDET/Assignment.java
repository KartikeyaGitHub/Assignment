package SDET;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class Assignment {
	private WebDriver driver;
    private String url = "https://testpages.herokuapp.com/styled/tag/dynamic-table.html";
    private String testData = "[{\"name\" : \"Bob\", \"age\" : 20, \"gender\": \"male\"}, "
                             + "{\"name\": \"George\", \"age\" : 42, \"gender\": \"male\"}, "
                             + "{\"name\": \"Sara\", \"age\" : 42, \"gender\": \"female\"}, "
                             + "{\"name\": \"Conor\", \"age\" : 40, \"gender\": \"male\"}, "
                             + "{\"name\": \"Jennifer\", \"age\" : 42, \"gender\": \"female\"}]";
    
    
	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		
	}
	
	@Test(priority=1)
	public void InsertDataAndRefresh() {
		driver.findElement(By.xpath("//summary[text()=\"Table Data\"]")).click();
		WebElement textArea = driver.findElement(By.id("jsondata"));
		textArea.clear();
		textArea.sendKeys(testData);
		driver.findElement(By.xpath("//button[text()=\"Refresh Table\"]")).click();
	}
	
	@Test(priority = 2)
    public void testTableDataAssertion() throws InterruptedException {
		Thread.sleep(8000);
        // Get table data from UI
    List<WebElement> tableRows = driver.findElements(By.xpath("//table[@id=\"dynamictable\"]/tr"));
    
    
    System.out.println("Number of rows in the table: " + tableRows.size());
        // Assert data
        for (int i = 1; i < tableRows.size(); i++) {
        	WebElement row = tableRows.get(i);
            List<WebElement> columns = row.findElements(By.tagName("td"));

            String name = columns.get(0).getText();
            int age = Integer.parseInt(columns.get(1).getText());
            String gender = columns.get(2).getText();
            
            String[] expectedData = testData.split("\"name\" : \"")[i + 1].split("\", \"age\" : ");
            Assert.assertEquals(name, expectedData[1]);
            Assert.assertEquals(age, Integer.parseInt(expectedData[1].split(", \"gender\"")[0]));
            Assert.assertEquals(gender, expectedData[1].split(", \"gender\" : \"")[1].split("\"")[0]);
         
        }
	
	
	}
	
	@AfterClass
	public void teardown() {
		driver.quit();
	}
}

